-- Basic_QUES-1: Retrieve the total number of orders placed.
select count(order_id) as Total_orders
from orders
